package dlmoreram011621_01;

public enum NavMode {
    DIRECT,
    BUGGING
}
