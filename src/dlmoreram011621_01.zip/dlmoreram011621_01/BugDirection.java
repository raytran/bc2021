package dlmoreram011621_01;

public enum BugDirection {
    LEFT, RIGHT
}
