package dlmoreram011021_03.nav;

public enum BugDirection {
    LEFT, RIGHT
}
