package dlmoreram011021_03.nav;

public enum NavMode {
    DIRECT,
    BUGGING
}
