package baseplayer3.nav;

public enum BugDirection {
    LEFT, RIGHT
}
