package baseplayer3.nav;

public enum NavMode {
    DIRECT,
    BUGGING
}
