package baseplayer3.eccontrollers;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;
import baseplayer3.BotEnlightenment;

public class ECBudgetController implements ECController {
    private final RobotController rc;
    private final BotEnlightenment ec;
    private final PIDDelta voteDelta = new PIDDelta(1.3047601758475982, 2.4800237809768406, 1.0887213666504725);
    private final PIDDelta botDelta = new PIDDelta(13.158057195493779, 2.166086632894662, 7.363325706736027);
    private final PIDDelta hpDelta = new PIDDelta(4.471332446906096, 11.200172291376639, 4.416029995483428);
    private int voteBudget;
    private int botBudget;
    private int hpBudget;


    public ECBudgetController(RobotController rc, BotEnlightenment ec) {
        this.rc = rc;
        this.ec = ec;
    }

    @Override
    public void run() throws GameActionException {
        int currentInfluence = rc.getInfluence();
        int currentRound = rc.getRoundNum();
        int income = currentInfluence - voteBudget - botBudget - hpBudget;

        //TODO: update PID targets
        /** add alpha, beta scaling factor to adjust early voting and bot budgets
         double alpha = Math.pow((double) rc.getRoundNum() / MAX_ROUNDS, 0.2);
         double beta = 1 + (1 - alpha);
         voteDelta *= alpha;
         botDelta *= beta; **/
        double voteTarget = 0.5 * currentRound < 250 ? (double) currentRound/250 : 1;
        double botTarget = currentRound * 0.25;
        double hpTarget = 1 + currentRound - ec.getLastEnemySeen() < 500 ? (int) (rc.getRoundNum() * 0.25) : (int) (rc.getRoundNum() * 0.05);

        // set new targets
        voteDelta.setTarget(voteTarget);
        botDelta.setTarget(botTarget);
        hpDelta.setTarget(hpTarget);

        // update deltas
        voteDelta.update((double) rc.getTeamVotes()/currentRound);
        botDelta.update(ec.getLocalRobotCount());
        hpDelta.update(hpBudget);

        // normalize to positive percentages
        double voteDValue = voteDelta.getValue();
        double botDValue = botDelta.getValue();
        double hpDValue = hpDelta.getValue();
        if (voteDValue < 0 || botDValue < 0 || hpDValue < 0 ) {
            double min = Math.min(voteDValue, Math.min(botDValue, hpDValue));
            voteDValue -= min;
            botDValue -= min;
            hpDValue -= min;
        }
        double total = voteDValue + botDValue + hpDValue;
        voteDValue *= total > 0 ? 1. / total : 1;
        botDValue *= total > 0 ? 1. / total : 0;

        int voteAllocation;
        int botAllocation;
        int hpAllocation;
        try {
            voteAllocation = (int) Math.round(voteDValue * income);
            botAllocation = (int) Math.round(botDValue * income);
            hpAllocation = income - voteAllocation - botAllocation;
            //assert income <= voteAllocation + botAllocation + hpAllocation;
            assert voteAllocation >= 0 && botAllocation >= 0 && hpAllocation >= 0;
        } catch (AssertionError e){
            voteAllocation = (int) Math.floor(voteDValue * income);
            botAllocation = (int) Math.floor(botDValue * income);
            hpAllocation = income - voteAllocation - botAllocation;
        }

        /** if there are nearby enemy politicians, make sure we have enough hp
        int enemyInfluence = ec.checkNearbyEnemies();
        if (hpBudget <= enemyInfluence && hpBudget != 0) {
            if (currentInfluence > enemyInfluence + 1) {
                hpBudget = enemyInfluence + 1;
                int remainingInfluence = currentInfluence - hpBudget;
                double newTotal = voteDValue + botDValue;
                voteAllocation = (int) (voteDValue / newTotal * remainingInfluence);
                botAllocation = remainingInfluence - (voteBudget + voteAllocation);
            } else {
                voteAllocation = 0;
                botAllocation = 0;
                hpBudget += income - 1;
                botBudget += 1;
            }
        }

        if (rc.getTeamVotes() > 1500) {
            botBudget += voteAllocation + botAllocation + voteBudget;
            voteBudget = 0;
        } else if (currentRound - ec.getLastBotSpawn() > 150) {
            voteBudget = voteAllocation + botAllocation + botBudget;
            botBudget = 0;
        } else {
            voteBudget += voteAllocation;
            botBudget += botAllocation;
        }**/

        voteBudget += voteAllocation;
        botBudget += botAllocation;
        hpBudget += hpAllocation;

    }

    /**
     * @return budget for making bids
     */
    public int getVoteBudget() {
        return voteBudget;
    }

    /**
     * @return budget for making bots
     */
    public int getBotBudget() {
        return botBudget;
    }

    /**
     * @return how much influence to save
     */
    public int getHpBudget() {
        return hpBudget;
    }

    public void withdrawBudget(ECSpawnController sc, int amount) { botBudget -= amount; }

    public void withdrawBudget(ECVoteController vc, int amount) { voteBudget -= amount; }

    public boolean canSpend (ECSpawnController sc, int amount) { return botBudget >= amount; }

    public boolean canSpend (ECVoteController vc, int amount) { return voteBudget >= amount; }
}
