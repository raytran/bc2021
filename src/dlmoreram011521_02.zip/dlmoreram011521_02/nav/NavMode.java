package dlmoreram011521_02.nav;

public enum NavMode {
    DIRECT,
    BUGGING
}
