package dlmoreram011521_02.nav;

public enum BugDirection {
    LEFT, RIGHT
}
