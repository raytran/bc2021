package dlmoreram012321_01.nav;

public enum BugDirection {
    LEFT, RIGHT
}
