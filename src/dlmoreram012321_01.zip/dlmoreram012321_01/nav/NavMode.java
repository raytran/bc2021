package dlmoreram012321_01.nav;

public enum NavMode {
    DIRECT,
    BUGGING
}
