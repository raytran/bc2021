package dlmoreram012121_02.nav;

public enum NavMode {
    DIRECT,
    BUGGING
}
