package dlmoreram012121_02.nav;

public enum BugDirection {
    LEFT, RIGHT
}
