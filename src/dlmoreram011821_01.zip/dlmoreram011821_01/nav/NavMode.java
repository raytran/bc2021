package dlmoreram011821_01.nav;

public enum NavMode {
    DIRECT,
    BUGGING
}
