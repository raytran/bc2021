package dlmoreram011121_01;

public enum BugDirection {
    LEFT, RIGHT
}
