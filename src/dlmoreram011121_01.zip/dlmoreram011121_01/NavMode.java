package dlmoreram011121_01;

public enum NavMode {
    DIRECT,
    BUGGING
}
