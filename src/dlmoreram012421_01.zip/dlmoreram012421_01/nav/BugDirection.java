package dlmoreram012421_01.nav;

public enum BugDirection {
    LEFT, RIGHT
}
