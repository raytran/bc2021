package dlmoreram012221_01.nav;

public enum BugDirection {
    LEFT, RIGHT
}
