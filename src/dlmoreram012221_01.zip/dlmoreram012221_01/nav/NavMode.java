package dlmoreram012221_01.nav;

public enum NavMode {
    DIRECT,
    BUGGING
}
