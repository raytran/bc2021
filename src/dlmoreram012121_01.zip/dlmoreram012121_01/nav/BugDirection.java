package dlmoreram012121_01.nav;

public enum BugDirection {
    LEFT, RIGHT
}
