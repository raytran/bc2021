package dlmoreram012121_01.nav;

public enum NavMode {
    DIRECT,
    BUGGING
}
