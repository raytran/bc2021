package dlmoreram012521_01.nav;

public enum BugDirection {
    LEFT, RIGHT
}
