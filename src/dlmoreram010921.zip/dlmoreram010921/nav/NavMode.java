package dlmoreram010921.nav;

public enum NavMode {
    DIRECT,
    BUGGING
}
