package dlmoreram010921.nav;

public enum BugDirection {
    LEFT, RIGHT
}
