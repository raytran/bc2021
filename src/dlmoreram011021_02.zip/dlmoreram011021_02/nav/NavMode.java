package dlmoreram011021_02.nav;

public enum NavMode {
    DIRECT,
    BUGGING
}
