package dlmoreram011021_02.nav;

public enum BugDirection {
    LEFT, RIGHT
}
