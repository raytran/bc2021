package dlmoreram011121_02.eccontrollers;

import battlecode.common.GameActionException;

public interface ECController {
    void run() throws GameActionException;
}
