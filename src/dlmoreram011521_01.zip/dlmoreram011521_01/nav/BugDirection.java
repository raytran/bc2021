package dlmoreram011521_01.nav;

public enum BugDirection {
    LEFT, RIGHT
}
