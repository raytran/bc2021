package dlmoreram011521_01.nav;

public enum NavMode {
    DIRECT,
    BUGGING
}
