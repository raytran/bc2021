package dlmoreram011021_01;

import battlecode.common.GameActionException;

public interface ECController {
    void run() throws GameActionException;
}
