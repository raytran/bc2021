package dlmoreram011021_01.flags;

public enum FlagAddress {
    ANY,
    PARENT_ENLIGHTENMENT_CENTER,
    ENLIGHTENMENT_CENTER,
    POLITICIAN,
    SLANDERER,
    MUCKRAKER;
    public static final FlagAddress[] values = values();
}
