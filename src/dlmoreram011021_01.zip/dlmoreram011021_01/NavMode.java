package dlmoreram011021_01;

public enum NavMode {
    DIRECT,
    BUGGING
}
