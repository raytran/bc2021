package dlmoreram011021_01;

public enum BugDirection {
    LEFT, RIGHT
}
